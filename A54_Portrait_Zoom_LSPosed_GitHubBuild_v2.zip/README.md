v4-lite safer slider build for Samsung Camera portrait zoom UI
