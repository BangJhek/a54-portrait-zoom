# A54 Portrait Zoom LSPosed (experimental)

Ini project Android Studio untuk module LSPosed yang coba ngebuka gating zoom di mode Portrait Samsung Camera.

## Target
- Package: `com.sec.android.app.camera`
- Device target awal: Galaxy A54
- Fokus: `PortraitZoomController` + `SingleBokehPortraitZoomController`

## Yang di-hook
- method boolean yang berbau `zoom/support/available/enable/show`
- `setSupportZoom(true)`
- `getKeepPortraitZoom()` / `setKeepPortraitZoom(true)`
- `getDefaultPortraitZoom()` / `getBokehLensZoomValue()`
- toast yang bilang zoom tidak bisa dipakai (sekadar indikator)

## Cara build
1. Buka project ini di Android Studio.
2. Pastikan Gradle sync jalan.
3. Build APK `debug` atau `release`.
4. Install APK ke HP.
5. Aktifkan module di LSPosed untuk package **Samsung Camera**.
6. Force stop Kamera, lalu buka lagi mode Portrait.

## Catatan
- Ini **eksperimen**, belum tentu sukses.
- Bisa jadi tombol tetap tidak muncul, atau kamera FC.
- Kalau kamera bermasalah, disable module di LSPosed lalu reboot.


## Build tanpa Android Studio
Lihat file `HOW_TO_BUILD_GITHUB.md`. Repo ini sudah disiapkan supaya bisa dibuild lewat **GitHub Actions** dan menghasilkan APK debug yang tinggal di-install.
