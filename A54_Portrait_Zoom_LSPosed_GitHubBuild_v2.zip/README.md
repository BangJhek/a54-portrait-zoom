A54 portrait zoom LSPosed v4: focus on forcing zoom slider visibility in Samsung Camera portrait mode.
