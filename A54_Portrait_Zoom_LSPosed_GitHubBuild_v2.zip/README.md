# A54 Portrait Zoom LSPosed - Lens List V6

Experimental LSPosed module for Samsung Camera on Galaxy A54.

Target for V6:
- keep portrait mode from crashing
- suppress zoom-not-supported toast
- inject a minimal portrait zoom lens list structure
- prefer safe 1x / 2x-from-main-camera behavior

This is experimental and not guaranteed to work.
