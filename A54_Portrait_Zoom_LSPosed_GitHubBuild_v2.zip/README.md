# A54 Portrait Zoom LSPosed v2

Eksperimen hook LSPosed untuk Samsung Camera (`com.sec.android.app.camera`) di Galaxy A54.

Perubahan v2:
- tambah hook `ShootingModeZoomController`
- paksa `isZoomAvailable*()` jadi true
- relaksasi `checkValidZoomLevel()`
- paksa `showZoomSlider()`
- normalisasi `onZoomValueChangeEventRequested()`
- suppress toast `not_supported_zoom_toast_popup`

Kalau masih gagal, ambil log LSPosed terbaru lalu cek tag:
`[A54PortraitZoomV2]`
