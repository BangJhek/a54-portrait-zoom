Upload semua isi zip ini ke repo GitHub, lalu jalankan workflow di `.github/workflows/build-apk.yml`.
Artifact hasil build berisi `app-debug.apk` untuk dipasang sebagai module LSPosed.
