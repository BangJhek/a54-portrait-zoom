# Cara build tanpa Android Studio

1. Buat repo baru di GitHub.
2. Upload seluruh isi zip ini ke repo itu.
3. Buka tab **Actions**.
4. Jalankan workflow **Build LSPosed APK**.
5. Tunggu selesai.
6. Download artifact **A54-Portrait-Zoom-LSPosed-debug-apk**.
7. Install `app-debug.apk` di HP.
8. Buka **LSPosed** > enable module ini > scope ke **Samsung Camera**.
9. Force stop Kamera Samsung lalu coba mode Potret.

## Catatan
- Ini masih eksperimen. Bisa jadi tidak ngaruh atau malah Samsung Camera FC.
- Kalau FC, nonaktifkan module di LSPosed lalu force stop Kamera.
- Build yang dihasilkan adalah **debug APK**, jadi langsung installable untuk ngetes.
