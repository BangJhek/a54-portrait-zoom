Upload this project to GitHub and run the included Actions workflow.
Artifact output: app/build/outputs/apk/debug/app-debug.apk
