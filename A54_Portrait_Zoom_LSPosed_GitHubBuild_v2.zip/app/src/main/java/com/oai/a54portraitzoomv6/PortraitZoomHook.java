
package com.oai.a54portraitzoomv6;

import android.view.View;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class PortraitZoomHook implements IXposedHookLoadPackage {
    private static final String TARGET_PKG = "com.sec.android.app.camera";

    private static final String CLS_ZOOM_LENS_LIST_VIEW = "com.sec.android.app.camera.layer.keyscreen.zoom.lenslist.ZoomLensListView";
    private static final String CLS_ZOOM_LENS_LIST_ADAPTER = "com.sec.android.app.camera.layer.keyscreen.zoom.lenslist.ZoomLensListAdapter";
    private static final String CLS_ZOOM_LENS_LIST_PRESENTER = "com.sec.android.app.camera.layer.keyscreen.zoom.lenslist.ZoomLensListPresenter";
    private static final String CLS_ZOOM_LENS_DATA = "com.sec.android.app.camera.layer.keyscreen.zoom.data.ZoomLensData";
    private static final String CLS_ZOOM_LENS_DATA_LIST = "com.sec.android.app.camera.layer.keyscreen.zoom.data.ZoomLensDataList";
    private static final String CLS_ZOOM_LENS_DATA_HOLDER = "com.sec.android.app.camera.interfaces.ZoomManager$ZoomLensDataHolder";

    private static final Set<String> GATE_CLASSES = new HashSet<>(Arrays.asList(
            "com.sec.android.app.camera.shootingmode.common.zoom.ShootingModeZoomController",
            "com.sec.android.app.camera.shootingmode.ShootingModeZoomControllerFactory",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitView",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitView"
    ));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) return;
        log("Loaded Samsung Camera process=" + lpparam.processName + ", installing lens-list v6 hooks");

        installToastBlock(lpparam.classLoader);
        installGateHooks(lpparam.classLoader);
        installLensListHooks(lpparam.classLoader);
    }

    private void installGateHooks(ClassLoader cl) {
        for (String className : GATE_CLASSES) {
            try {
                Class<?> cls = XposedHelpers.findClass(className, cl);
                log("Hooking gate class: " + className);
                for (Method m : cls.getDeclaredMethods()) {
                    if (Modifier.isAbstract(m.getModifiers()) || Modifier.isNative(m.getModifiers())) continue;
                    final String name = m.getName();
                    final String lower = name.toLowerCase(Locale.ROOT);
                    final Class<?> rt = m.getReturnType();

                    if ((rt == boolean.class || rt == Boolean.class) && isSafeZoomGate(lower)) {
                        XposedBridge.hookMethod(m, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) {
                                param.setResult(true);
                            }
                        });
                        continue;
                    }

                    if (name.equals("showZoomNotSupportedToast")
                            || name.equals("showZoomRestrictionToast")
                            || name.equals("onZoomNotSupportedToastShowRequested")
                            || name.equals("onZoomRestrictionToastShowRequested")) {
                        XposedBridge.hookMethod(m, new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) {
                                setNeutralResult(param, rt);
                                log("Suppressed portrait zoom restriction gate: " + className + "#" + name);
                            }
                        });
                    }
                }
            } catch (Throwable t) {
                log("Skip gate class " + className + ": " + t.getClass().getSimpleName() + " " + t.getMessage());
            }
        }
    }

    private void installLensListHooks(ClassLoader cl) {
        try {
            Class<?> viewCls = XposedHelpers.findClass(CLS_ZOOM_LENS_LIST_VIEW, cl);
            log("Hooking lens list view");
            for (Method m : viewCls.getDeclaredMethods()) {
                final String name = m.getName();
                final String lower = name.toLowerCase(Locale.ROOT);
                final Class<?> rt = m.getReturnType();
                if (Modifier.isAbstract(m.getModifiers()) || Modifier.isNative(m.getModifiers())) continue;

                if (name.equals("validateZoomLensDataList")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ensureLensStructures(param.thisObject, cl);
                            setNeutralResult(param, rt);
                            log("Bypassed validateZoomLensDataList after injecting fallback lens structures");
                        }
                    });
                    continue;
                }

                if (name.equals("getSelectedButtonPosition") || name.equals("getSelectedItemPosition")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ensureLensStructures(param.thisObject, cl);
                            if (rt == int.class || rt == Integer.class) {
                                param.setResult(0);
                            } else {
                                setNeutralResult(param, rt);
                            }
                        }
                    });
                    continue;
                }

                if (name.equals("notifyZoomLensList") || name.equals("showZoomLensShortcut") || name.equals("onZoomLensShortcutShow")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ensureLensStructures(param.thisObject, cl);
                            coerceLensArgs(param.args, cl);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            forceVisible(param.thisObject);
                            forceVisibleFromFields(param.thisObject);
                        }
                    });
                    continue;
                }

                if ((rt == boolean.class || rt == Boolean.class)
                        && (lower.contains("zoom") || lower.contains("lens"))
                        && (lower.startsWith("is") || lower.startsWith("can") || lower.startsWith("has") || lower.contains("valid") || lower.contains("support") || lower.contains("available"))) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ensureLensStructures(param.thisObject, cl);
                            if (name.contains("valid") || lower.contains("selected")) {
                                // let selection-specific paths stay conservative
                                return;
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (!name.toLowerCase(Locale.ROOT).contains("selected")) {
                                param.setResult(true);
                            }
                        }
                    });
                }
            }
        } catch (Throwable t) {
            log("Lens list view hooks failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }

        try {
            Class<?> adapterCls = XposedHelpers.findClass(CLS_ZOOM_LENS_LIST_ADAPTER, cl);
            log("Hooking lens list adapter");
            for (Method m : adapterCls.getDeclaredMethods()) {
                final String name = m.getName();
                final String lower = name.toLowerCase(Locale.ROOT);
                final Class<?> rt = m.getReturnType();
                if (Modifier.isAbstract(m.getModifiers()) || Modifier.isNative(m.getModifiers())) continue;

                if (name.equals("isSelectedItem") || name.equals("isSelectedChild")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ensureLensStructures(param.thisObject, cl);
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(false);
                            } else {
                                setNeutralResult(param, rt);
                            }
                        }
                    });
                    continue;
                }

                if (name.equals("getItemCount") || name.equals("getCount")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ensureLensStructures(param.thisObject, cl);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.getResult() instanceof Number) {
                                int count = ((Number) param.getResult()).intValue();
                                if (count <= 0) {
                                    param.setResult(2);
                                    log("Normalized empty lens adapter count to 2");
                                }
                            }
                        }
                    });
                    continue;
                }

                if (name.equals("notifyDataSetChanged") || name.equals("updateZoomLensShortcutButton")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ensureLensStructures(param.thisObject, cl);
                            coerceLensArgs(param.args, cl);
                        }
                    });
                    continue;
                }

                if ((rt == boolean.class || rt == Boolean.class) && lower.contains("zoom") && lower.contains("valid")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                        }
                    });
                }
            }
        } catch (Throwable t) {
            log("Lens list adapter hooks failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }

        try {
            Class<?> presenterCls = XposedHelpers.findClass(CLS_ZOOM_LENS_LIST_PRESENTER, cl);
            log("Hooking lens list presenter");
            for (Method m : presenterCls.getDeclaredMethods()) {
                final String name = m.getName();
                final String lower = name.toLowerCase(Locale.ROOT);
                final Class<?> rt = m.getReturnType();
                if (Modifier.isAbstract(m.getModifiers()) || Modifier.isNative(m.getModifiers())) continue;

                if (name.equals("getZoomLensDataHolder") || name.equals("createLensDataHolder")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.getResult() == null) {
                                Object holder = buildFallbackHolder(cl);
                                if (holder != null && rt.isInstance(holder)) {
                                    param.setResult(holder);
                                    log("Injected fallback ZoomLensDataHolder");
                                }
                            }
                        }
                    });
                    continue;
                }

                if (name.equals("setZoomLensDataHolder") || name.equals("notifyZoomLensList") || name.equals("handleZoomLensShortcut") || name.equals("handleZoomLensShortcutButtonClickEvent")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ensureLensStructures(param.thisObject, cl);
                            coerceLensArgs(param.args, cl);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            forceVisibleFromFields(param.thisObject);
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                        }
                    });
                    continue;
                }

                if ((rt == boolean.class || rt == Boolean.class) && (lower.contains("zoom") || lower.contains("lens")) && (lower.contains("show") || lower.contains("support") || lower.contains("available") || lower.contains("valid"))) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                        }
                    });
                }
            }
        } catch (Throwable t) {
            log("Lens list presenter hooks failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private void installToastBlock(ClassLoader cl) {
        try {
            Class<?> toast = XposedHelpers.findClass("android.widget.Toast", cl);
            XposedHelpers.findAndHookMethod(toast, "makeText", android.content.Context.class, CharSequence.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args != null && param.args.length >= 2 && param.args[1] instanceof CharSequence) {
                                String s = param.args[1].toString().toLowerCase(Locale.ROOT);
                                if (s.contains("tidak dapat memperbesar")
                                        || s.contains("cannot zoom")
                                        || s.contains("memperbesar atau memperkecil")
                                        || s.contains("zoom not supported")) {
                                    log("Blocked zoom restriction toast text");
                                    param.args[1] = "Portrait zoom lens list v6 active";
                                }
                            }
                        }
                    });
        } catch (Throwable t) {
            log("Toast hook skipped: " + t.getMessage());
        }
    }

    private void coerceLensArgs(Object[] args, ClassLoader cl) {
        if (args == null) return;
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (a == null) continue;
            try {
                String cn = a.getClass().getName().toLowerCase(Locale.ROOT);
                if (cn.contains("zoomlensdataholder")) {
                    fillHolder(a, cl);
                } else if (cn.contains("zoomlensdatalist")) {
                    fillLensDataList(a, cl);
                } else if (a instanceof List && ((List<?>) a).isEmpty()) {
                    args[i] = buildFallbackJavaList(cl);
                } else if (a instanceof Boolean) {
                    args[i] = true;
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private void ensureLensStructures(Object obj, ClassLoader cl) {
        if (obj == null) return;
        try {
            for (Field f : getAllFields(obj.getClass())) {
                f.setAccessible(true);
                String name = f.getName().toLowerCase(Locale.ROOT);
                Class<?> type = f.getType();
                Object cur = null;
                try { cur = f.get(obj); } catch (Throwable ignored) {}

                if (name.contains("lensdatalist")) {
                    if (cur == null) {
                        Object val = buildFallbackLensDataListObject(cl, type);
                        if (val != null && type.isInstance(val)) {
                            f.set(obj, val);
                            log("Injected field " + f.getName() + " with fallback lens data list object");
                        }
                    } else {
                        fillLensDataList(cur, cl);
                    }
                } else if (name.contains("zoomlensdataholder")) {
                    if (cur == null) {
                        Object holder = buildFallbackHolder(cl);
                        if (holder != null && type.isInstance(holder)) {
                            f.set(obj, holder);
                            log("Injected field " + f.getName() + " with fallback holder");
                        }
                    } else {
                        fillHolder(cur, cl);
                    }
                } else if ((name.contains("zoomlensarray") || name.contains("lenslist") || name.contains("datalist")) && List.class.isAssignableFrom(type)) {
                    if (cur == null || ((List<?>) cur).isEmpty()) {
                        ArrayList<Object> list = buildFallbackJavaList(cl);
                        f.set(obj, list);
                        log("Injected Java fallback list into field " + f.getName());
                    }
                } else if (name.contains("zoomlensarray") && type.isArray() && Array.getLength(cur != null ? cur : Array.newInstance(type.getComponentType(), 0)) == 0) {
                    Object arr = buildFallbackArray(type.getComponentType(), cl);
                    if (arr != null) {
                        f.set(obj, arr);
                        log("Injected fallback array into field " + f.getName());
                    }
                }
            }
        } catch (Throwable t) {
            log("ensureLensStructures failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private Object buildFallbackArray(Class<?> component, ClassLoader cl) {
        try {
            Object arr = Array.newInstance(component, 2);
            Object item1 = buildFallbackLensDataObject(cl, 1.0f, "1x", true);
            Object item2 = buildFallbackLensDataObject(cl, 2.0f, "2x", false);
            if (component.isInstance(item1)) Array.set(arr, 0, item1);
            if (component.isInstance(item2)) Array.set(arr, 1, item2);
            return arr;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private ArrayList<Object> buildFallbackJavaList(ClassLoader cl) {
        ArrayList<Object> list = new ArrayList<>();
        Object one = buildFallbackLensDataObject(cl, 1.0f, "1x", true);
        Object two = buildFallbackLensDataObject(cl, 2.0f, "2x", false);
        if (one != null) list.add(one);
        if (two != null) list.add(two);
        return list;
    }

    private Object buildFallbackLensDataListObject(ClassLoader cl, Class<?> targetType) {
        try {
            Object obj = instantiateLenient(targetType, cl, 0);
            if (obj != null) {
                fillLensDataList(obj, cl);
                return obj;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private void fillLensDataList(Object obj, ClassLoader cl) {
        if (obj == null) return;
        try {
            if (obj instanceof List) {
                List<Object> list = (List<Object>) obj;
                if (list.isEmpty()) {
                    list.addAll(buildFallbackJavaList(cl));
                    log("Filled lens data list java.util.List with fallback 1x/2x entries");
                }
                return;
            }

            for (Field f : getAllFields(obj.getClass())) {
                f.setAccessible(true);
                String name = f.getName().toLowerCase(Locale.ROOT);
                Class<?> type = f.getType();
                Object cur = null;
                try { cur = f.get(obj); } catch (Throwable ignored) {}

                if ((name.contains("list") || name.contains("array")) && List.class.isAssignableFrom(type)) {
                    if (cur == null || ((List<?>) cur).isEmpty()) {
                        ArrayList<Object> list = buildFallbackJavaList(cl);
                        f.set(obj, list);
                        log("Filled internal list field " + f.getName() + " with fallback 1x/2x entries");
                    }
                } else if ((name.contains("count") || name.contains("size")) && (type == int.class || type == Integer.class)) {
                    if (cur == null || ((Number) cur).intValue() <= 0) {
                        f.set(obj, 2);
                    }
                } else if (name.contains("selected") && (type == int.class || type == Integer.class)) {
                    f.set(obj, 0);
                }
            }

            // try add(...) if present
            for (Method m : obj.getClass().getDeclaredMethods()) {
                if (m.getParameterCount() == 1 && m.getName().equals("add")) {
                    Class<?> p = m.getParameterTypes()[0];
                    Object one = buildFallbackLensDataObject(cl, 1.0f, "1x", true);
                    Object two = buildFallbackLensDataObject(cl, 2.0f, "2x", false);
                    if (one != null && p.isInstance(one)) {
                        m.setAccessible(true);
                        m.invoke(obj, one);
                    }
                    if (two != null && p.isInstance(two)) {
                        m.setAccessible(true);
                        m.invoke(obj, two);
                    }
                    log("Filled lens data list via add(...) with fallback entries");
                    break;
                }
            }
        } catch (Throwable t) {
            log("fillLensDataList failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private Object buildFallbackHolder(ClassLoader cl) {
        try {
            Class<?> holderCls = XposedHelpers.findClass(CLS_ZOOM_LENS_DATA_HOLDER, cl);
            Object holder = instantiateLenient(holderCls, cl, 0);
            fillHolder(holder, cl);
            return holder;
        } catch (Throwable t) {
            log("buildFallbackHolder failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
            return null;
        }
    }

    private void fillHolder(Object holder, ClassLoader cl) {
        if (holder == null) return;
        try {
            for (Field f : getAllFields(holder.getClass())) {
                f.setAccessible(true);
                String name = f.getName().toLowerCase(Locale.ROOT);
                Class<?> type = f.getType();
                Object cur = null;
                try { cur = f.get(holder); } catch (Throwable ignored) {}

                if (name.contains("lensdatalist")) {
                    if (cur == null) {
                        Object val = buildFallbackLensDataListObject(cl, type);
                        if (val != null && type.isInstance(val)) {
                            f.set(holder, val);
                        }
                    } else {
                        fillLensDataList(cur, cl);
                    }
                } else if ((name.contains("zoomlensarray") || name.contains("list")) && List.class.isAssignableFrom(type)) {
                    if (cur == null || ((Collection<?>) cur).isEmpty()) {
                        f.set(holder, buildFallbackJavaList(cl));
                    }
                } else if (name.contains("selected") && (type == int.class || type == Integer.class)) {
                    f.set(holder, 0);
                } else if ((name.contains("count") || name.contains("size")) && (type == int.class || type == Integer.class)) {
                    f.set(holder, 2);
                }
            }
        } catch (Throwable t) {
            log("fillHolder failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private Object buildFallbackLensDataObject(ClassLoader cl, float zoomValue, String label, boolean selected) {
        try {
            Class<?> lensCls = XposedHelpers.findClass(CLS_ZOOM_LENS_DATA, cl);
            Object obj = instantiateLenient(lensCls, cl, 0);
            if (obj == null) return null;
            fillLensDataObject(obj, zoomValue, label, selected, cl);
            return obj;
        } catch (Throwable t) {
            log("buildFallbackLensDataObject failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
            return null;
        }
    }

    private void fillLensDataObject(Object obj, float zoomValue, String label, boolean selected, ClassLoader cl) {
        if (obj == null) return;
        try {
            for (Field f : getAllFields(obj.getClass())) {
                f.setAccessible(true);
                String name = f.getName().toLowerCase(Locale.ROOT);
                Class<?> type = f.getType();
                if ((name.contains("zoom") || name.contains("value") || name.contains("ratio")) && (type == float.class || type == Float.class)) {
                    f.set(obj, zoomValue);
                } else if ((name.contains("zoom") || name.contains("value") || name.contains("ratio")) && (type == double.class || type == Double.class)) {
                    f.set(obj, (double) zoomValue);
                } else if ((name.contains("zoom") || name.contains("value") || name.contains("ratio")) && (type == int.class || type == Integer.class)) {
                    f.set(obj, Math.round(zoomValue));
                } else if ((name.contains("text") || name.contains("name") || name.contains("title") || name.contains("label")) && type == String.class) {
                    f.set(obj, label);
                } else if (name.contains("selected") && (type == boolean.class || type == Boolean.class)) {
                    f.set(obj, selected);
                } else if (name.contains("visible") && (type == boolean.class || type == Boolean.class)) {
                    f.set(obj, true);
                }
            }

            for (Method m : obj.getClass().getDeclaredMethods()) {
                if (m.getParameterCount() != 1) continue;
                m.setAccessible(true);
                String name = m.getName().toLowerCase(Locale.ROOT);
                Class<?> p = m.getParameterTypes()[0];
                try {
                    if ((name.contains("zoom") || name.contains("value") || name.contains("ratio")) && (p == float.class || p == Float.class)) {
                        m.invoke(obj, zoomValue);
                    } else if ((name.contains("zoom") || name.contains("value") || name.contains("ratio")) && (p == double.class || p == Double.class)) {
                        m.invoke(obj, (double) zoomValue);
                    } else if ((name.contains("zoom") || name.contains("value") || name.contains("ratio")) && (p == int.class || p == Integer.class)) {
                        m.invoke(obj, Math.round(zoomValue));
                    } else if ((name.contains("name") || name.contains("text") || name.contains("label") || name.contains("title")) && p == String.class) {
                        m.invoke(obj, label);
                    } else if (name.contains("selected") && (p == boolean.class || p == Boolean.class)) {
                        m.invoke(obj, selected);
                    } else if (name.contains("visible") && (p == boolean.class || p == Boolean.class)) {
                        m.invoke(obj, true);
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable t) {
            log("fillLensDataObject failed: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private Object instantiateLenient(Class<?> cls, ClassLoader cl, int depth) {
        if (cls == null || depth > 2) return null;
        try {
            Constructor<?> best = null;
            for (Constructor<?> c : cls.getDeclaredConstructors()) {
                if (best == null || c.getParameterCount() < best.getParameterCount()) {
                    best = c;
                }
            }
            if (best == null) return null;
            best.setAccessible(true);
            Class<?>[] pts = best.getParameterTypes();
            Object[] args = new Object[pts.length];
            for (int i = 0; i < pts.length; i++) {
                args[i] = defaultArg(pts[i], cl, depth + 1);
            }
            return best.newInstance(args);
        } catch (Throwable t) {
            log("instantiateLenient failed for " + cls.getName() + ": " + t.getClass().getSimpleName());
            return null;
        }
    }

    private Object defaultArg(Class<?> type, ClassLoader cl, int depth) {
        if (type == boolean.class || type == Boolean.class) return false;
        if (type == int.class || type == Integer.class) return 0;
        if (type == long.class || type == Long.class) return 0L;
        if (type == float.class || type == Float.class) return 1.0f;
        if (type == double.class || type == Double.class) return 1.0d;
        if (type == short.class || type == Short.class) return (short) 0;
        if (type == byte.class || type == Byte.class) return (byte) 0;
        if (type == char.class || type == Character.class) return (char) 0;
        if (type == String.class) return null;
        if (List.class.isAssignableFrom(type)) return new ArrayList<>();
        if (type.isArray()) return Array.newInstance(type.getComponentType(), 0);
        if (type.isEnum()) {
            Object[] constants = type.getEnumConstants();
            return (constants != null && constants.length > 0) ? constants[0] : null;
        }
        String n = type.getName();
        if (n.contains("ZoomLensDataHolder") || n.contains("ZoomLensDataList") || n.contains("ZoomLensData")) {
            return instantiateLenient(type, cl, depth + 1);
        }
        return null;
    }

    private void forceVisible(Object obj) {
        if (obj == null) return;
        try {
            if (obj instanceof View) {
                View v = (View) obj;
                if (v.getVisibility() != View.VISIBLE) v.setVisibility(View.VISIBLE);
            }
        } catch (Throwable ignored) {
        }
    }

    private void forceVisibleFromFields(Object obj) {
        if (obj == null) return;
        try {
            for (Field f : getAllFields(obj.getClass())) {
                f.setAccessible(true);
                Object val = null;
                try { val = f.get(obj); } catch (Throwable ignored) {}
                forceVisible(val);
            }
        } catch (Throwable ignored) {
        }
    }

    private boolean isSafeZoomGate(String lower) {
        boolean mentionsZoom = lower.contains("zoom") || lower.contains("slider") || lower.contains("shortcut") || lower.contains("portrait") || lower.contains("bokeh") || lower.contains("lens");
        boolean isGate = lower.startsWith("is") || lower.startsWith("can") || lower.startsWith("has")
                || lower.contains("support") || lower.contains("available") || lower.contains("visible")
                || lower.contains("show") || lower.contains("enable") || lower.contains("valid");
        boolean negative = lower.contains("notsupported") || lower.contains("restriction") || lower.contains("hide")
                || lower.contains("collapse") || lower.contains("init") || lower.contains("initialized");
        return mentionsZoom && isGate && !negative;
    }

    private List<Field> getAllFields(Class<?> cls) {
        ArrayList<Field> out = new ArrayList<>();
        Class<?> cur = cls;
        while (cur != null && cur != Object.class) {
            out.addAll(Arrays.asList(cur.getDeclaredFields()));
            cur = cur.getSuperclass();
        }
        return out;
    }

    private void setNeutralResult(XC_MethodHook.MethodHookParam param, Class<?> rt) {
        if (rt == boolean.class || rt == Boolean.class) param.setResult(true);
        else if (rt == int.class || rt == Integer.class) param.setResult(0);
        else if (rt == float.class || rt == Float.class) param.setResult(1.0f);
        else if (rt == double.class || rt == Double.class) param.setResult(1.0d);
        else param.setResult(null);
    }

    private static void log(String msg) {
        XposedBridge.log("[A54PortraitZoomLensListV6] " + msg);
    }
}
