package com.oai.a54portraitzoomv5;

import android.view.View;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class PortraitZoomHook implements IXposedHookLoadPackage {
    private static final String TARGET_PKG = "com.sec.android.app.camera";
    private static final Set<String> TARGET_CLASSES = new HashSet<>(Arrays.asList(
            "com.sec.android.app.camera.shootingmode.common.zoom.ShootingModeZoomController",
            "com.sec.android.app.camera.shootingmode.ShootingModeZoomControllerFactory",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitView",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitView",
            "com.sec.android.app.camera.layer.keyscreen.zoom.slider.ZoomSliderPresenter",
            "com.sec.android.app.camera.layer.keyscreen.zoom.slider.ZoomSliderView",
            "com.sec.android.app.camera.layer.keyscreen.zoom.widget.ZoomShortcutListView",
            "com.sec.android.app.camera.layer.keyscreen.zoom.widget.ZoomShortcutListAdapter",
            "com.sec.android.app.camera.shootingmode.common.zoomrocker.ZoomRockerSlider"
    ));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) return;
        log("Loaded Samsung Camera process=" + lpparam.processName + ", installing clean v5 hooks");

        for (String cls : TARGET_CLASSES) {
            hookTargetClass(lpparam.classLoader, cls);
        }

        installToastBlock(lpparam.classLoader);
        installViewVisibilityHooks(lpparam.classLoader);
    }

    private void hookTargetClass(ClassLoader cl, String className) {
        try {
            Class<?> cls = XposedHelpers.findClass(className, cl);
            log("Hooking class: " + className);

            for (Method m : cls.getDeclaredMethods()) {
                final String name = m.getName();
                final String lower = name.toLowerCase(Locale.ROOT);
                final Class<?> rt = m.getReturnType();
                final int pc = m.getParameterCount();

                if (Modifier.isAbstract(m.getModifiers()) || Modifier.isNative(m.getModifiers())) continue;

                // Never touch initialization state again; v4 crashed here.
                if (name.equals("isSliderInitialized") || lower.contains("sliderinitialized")) {
                    continue;
                }

                // Suppress obvious zoom restriction paths.
                if (name.equals("showZoomNotSupportedToast")
                        || name.equals("showZoomRestrictionToast")
                        || name.equals("onZoomNotSupportedToastShowRequested")
                        || name.equals("onZoomRestrictionToastShowRequested")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            log("Suppressed restriction toast gate: " + className + "#" + name);
                            setNeutralResult(param, rt);
                        }
                    });
                    continue;
                }

                // Keep UI from being hidden. Do not fake init/expand.
                if (name.equals("hideZoomSlider")
                        || name.equals("hideZoomShortcut")
                        || name.equals("hideZoomRockerSlider")
                        || name.equals("collapseZoomSlider")
                        || name.equals("handleZoomSliderCollapse")
                        || name.equals("onZoomSliderHide")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            log("Blocked hide path: " + className + "#" + name);
                            setNeutralResult(param, rt);
                        }
                    });
                    continue;
                }

                // Force safe availability/support gates only.
                if ((rt == boolean.class || rt == Boolean.class) && isSafeZoomGate(lower)) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                            log("Forced safe gate true: " + className + "#" + name);
                        }
                    });
                    continue;
                }

                // Make show paths succeed, but do not manually initialize slider internals.
                if (name.equals("showZoomSlider")
                        || name.equals("showZoomLensShortcut")
                        || name.equals("showZoomShortcut")
                        || name.equals("showZoomRockerSlider")
                        || name.equals("onZoomShortcutShow")
                        || name.equals("showZoomBar")
                        || name.equals("showZoomControl")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            coerceArgs(name, param.args);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                            forceVisible(param.thisObject);
                            if (param.args != null) {
                                for (Object a : param.args) forceVisible(a);
                            }
                        }
                    });
                    continue;
                }

                // Keep portrait zoom state enabled.
                if ((name.equals("setKeepPortraitZoom") && pc == 1)
                        || name.equals("getKeepPortraitZoom")
                        || name.equals("isKeepPortraitZoom")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (name.equals("setKeepPortraitZoom") && param.args != null && param.args.length == 1) {
                                param.args[0] = true;
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                        }
                    });
                    continue;
                }

                // Relax validation but don't fake slider init.
                if (name.equals("checkValidZoomLevel")
                        || name.equals("validateZoomLensDataList")
                        || name.equals("canUpdateZoom")
                        || name.equals("isZoomAvailable")
                        || name.equals("isZoomSupported")
                        || name.equals("isZoomSliderAvailable")
                        || name.equals("hasZoomShortcut")
                        || name.equals("isZoomShortcutVisible")
                        || name.equals("isZoomControlVisible")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            coerceArgs(name, param.args);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            } else if (rt == int.class || rt == Integer.class) {
                                param.setResult(1);
                            }
                            forceVisible(param.thisObject);
                            log("Relaxed validation path: " + className + "#" + name);
                        }
                    });
                    continue;
                }

                // Normalize zoom values to sensible portrait-friendly range.
                if (name.equals("getDefaultPortraitZoom")
                        || name.equals("getBokehLensZoomValue")
                        || name.equals("getMinZoomValue")
                        || name.equals("getMaxZoomValue")
                        || name.equals("getZoomValue")
                        || name.equals("getDisplayZoomValue")
                        || name.equals("getWideZoomShortcutLevel")
                        || name.equals("getTeleZoomShortcutLevel")
                        || name.equals("getSecondTeleZoomShortcutLevel")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            fixNumericResult(name, rt, param);
                        }
                    });
                    continue;
                }

                if (name.equals("setZoomValue")
                        || name.equals("setZoomLevel")
                        || name.equals("updateZoomValue")
                        || name.equals("notifyZoomLevel")
                        || name.equals("onZoomValueChangeEventRequested")
                        || name.equals("onZoomValueChangeRequested")
                        || name.equals("scrollSliderByZoomValue")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            coerceArgs(name, param.args);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                            forceVisible(param.thisObject);
                        }
                    });
                    continue;
                }

                if (name.equals("getZoomShortcutCommandIdList") && List.class.isAssignableFrom(rt)) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.getResult() == null) {
                                param.setResult(new java.util.ArrayList<>());
                                log("Normalized null shortcut list: " + className + "#" + name);
                            }
                        }
                    });
                }
            }
        } catch (Throwable t) {
            log("Skip class " + className + ": " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private void installViewVisibilityHooks(ClassLoader cl) {
        hookViewVisibility(cl, "com.sec.android.app.camera.layer.keyscreen.zoom.widget.ZoomShortcutListView");
        hookViewVisibility(cl, "com.sec.android.app.camera.shootingmode.common.zoomrocker.ZoomRockerSlider");
    }

    private void hookViewVisibility(ClassLoader cl, String className) {
        try {
            Class<?> cls = XposedHelpers.findClass(className, cl);
            XposedHelpers.findAndHookMethod(cls, "setVisibility", int.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args != null && param.args.length == 1 && param.args[0] instanceof Integer) {
                        int v = (Integer) param.args[0];
                        if (v != View.VISIBLE) {
                            param.args[0] = View.VISIBLE;
                            log("Forced visible: " + className + "#setVisibility(" + v + "->VISIBLE)");
                        }
                    }
                }
            });
        } catch (Throwable t) {
            log("View visibility hook skipped for " + className + ": " + t.getClass().getSimpleName());
        }
    }

    private boolean isSafeZoomGate(String lower) {
        boolean mentionsZoom = lower.contains("zoom") || lower.contains("slider") || lower.contains("shortcut") || lower.contains("portrait") || lower.contains("bokeh");
        boolean isGate = lower.startsWith("is") || lower.startsWith("can") || lower.startsWith("has")
                || lower.contains("support") || lower.contains("available") || lower.contains("visible")
                || lower.contains("show") || lower.contains("enable");
        boolean negative = lower.contains("notsupported") || lower.contains("restriction") || lower.contains("hide")
                || lower.contains("collapse") || lower.contains("init") || lower.contains("initialized");
        return mentionsZoom && isGate && !negative;
    }

    private void coerceArgs(String name, Object[] args) {
        if (args == null) return;
        String lowerName = name.toLowerCase(Locale.ROOT);
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (a instanceof Boolean) {
                args[i] = true;
            } else if (a instanceof Float) {
                float v = (Float) a;
                if (lowerName.contains("min")) v = 0.5f;
                else if (lowerName.contains("max")) v = Math.max(v, 2.0f);
                else if (v < 0.5f) v = 1.0f;
                else if (v > 10.0f) v = 2.0f;
                args[i] = v;
            } else if (a instanceof Double) {
                double v = (Double) a;
                if (lowerName.contains("min")) v = 0.5d;
                else if (lowerName.contains("max")) v = Math.max(v, 2.0d);
                else if (v < 0.5d) v = 1.0d;
                else if (v > 10.0d) v = 2.0d;
                args[i] = v;
            } else if (a instanceof Integer) {
                int v = (Integer) a;
                if (v < 0) v = 1;
                args[i] = v;
            }
        }
    }

    private void fixNumericResult(String name, Class<?> rt, XC_MethodHook.MethodHookParam param) {
        if (rt == float.class || rt == Float.class) {
            float v = param.getResult() instanceof Number ? ((Number) param.getResult()).floatValue() : 1.0f;
            if (name.contains("Min")) v = 0.5f;
            else if (name.contains("Max")) v = Math.max(v, 2.0f);
            else if (name.contains("Wide")) v = 0.5f;
            else if (name.contains("Tele")) v = 2.0f;
            else if (v < 0.5f) v = 1.0f;
            param.setResult(v);
        } else if (rt == double.class || rt == Double.class) {
            double v = param.getResult() instanceof Number ? ((Number) param.getResult()).doubleValue() : 1.0d;
            if (name.contains("Min")) v = 0.5d;
            else if (name.contains("Max")) v = Math.max(v, 2.0d);
            else if (name.contains("Wide")) v = 0.5d;
            else if (name.contains("Tele")) v = 2.0d;
            else if (v < 0.5d) v = 1.0d;
            param.setResult(v);
        } else if (rt == int.class || rt == Integer.class) {
            int v = param.getResult() instanceof Number ? ((Number) param.getResult()).intValue() : 1;
            if (name.contains("Min")) v = 0;
            else if (name.contains("Max")) v = Math.max(v, 2);
            else if (name.contains("Wide")) v = 0;
            else if (name.contains("Tele")) v = 2;
            else if (v < 0) v = 1;
            param.setResult(v);
        }
    }

    private void forceVisible(Object obj) {
        if (obj == null) return;
        try {
            if (obj instanceof View) {
                View v = (View) obj;
                if (v.getVisibility() != View.VISIBLE) {
                    v.setVisibility(View.VISIBLE);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void installToastBlock(ClassLoader cl) {
        try {
            Class<?> toast = XposedHelpers.findClass("android.widget.Toast", cl);
            XposedHelpers.findAndHookMethod(toast, "makeText", android.content.Context.class, CharSequence.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args != null && param.args.length >= 2 && param.args[1] instanceof CharSequence) {
                                String s = param.args[1].toString().toLowerCase(Locale.ROOT);
                                if (s.contains("tidak dapat memperbesar")
                                        || s.contains("cannot zoom")
                                        || s.contains("memperbesar atau memperkecil")
                                        || s.contains("zoom not supported")) {
                                    log("Blocked zoom toast text");
                                    param.args[1] = "Portrait zoom unlock clean v5 active";
                                }
                            }
                        }
                    });
        } catch (Throwable t) {
            log("Toast hook skipped: " + t.getMessage());
        }
    }

    private void setNeutralResult(XC_MethodHook.MethodHookParam param, Class<?> rt) {
        if (rt == boolean.class || rt == Boolean.class) param.setResult(true);
        else if (rt == int.class || rt == Integer.class) param.setResult(0);
        else if (rt == float.class || rt == Float.class) param.setResult(1.0f);
        else if (rt == double.class || rt == Double.class) param.setResult(1.0d);
        else param.setResult(null);
    }

    private static void log(String msg) {
        XposedBridge.log("[A54PortraitZoomCleanV5] " + msg);
    }
}
