package com.oai.a54portraitzoom;

import android.content.Context;
import android.content.res.Resources;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class PortraitZoomHook implements IXposedHookLoadPackage {
    private static final String TARGET_PKG = "com.sec.android.app.camera";

    private static final Set<String> TARGET_CLASSES = new HashSet<>(Arrays.asList(
            "com.sec.android.app.camera.shootingmode.common.zoom.ShootingModeZoomController",
            "com.sec.android.app.camera.shootingmode.ShootingModeZoomControllerFactory",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitView",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitView"
    ));

    private static final float MIN_ZOOM = 0.5f;
    private static final float DEFAULT_ZOOM = 1.0f;
    private static final float MAX_ZOOM = 2.0f;
    private static final Set<String> loggedCalls = new HashSet<>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) return;

        log("Loaded Samsung Camera process=" + lpparam.processName + ", installing portrait zoom hooks v2");

        for (String cls : TARGET_CLASSES) {
            hookTargetClass(lpparam.classLoader, cls);
        }

        hookToastSuppression(lpparam.classLoader);
    }

    private void hookTargetClass(ClassLoader cl, String className) {
        try {
            Class<?> cls = XposedHelpers.findClass(className, cl);
            log("Hooking class: " + className);

            for (Method m : cls.getDeclaredMethods()) {
                final String methodName = m.getName();
                final String lower = methodName.toLowerCase(Locale.ROOT);
                final Class<?> returnType = m.getReturnType();

                if (methodName.equals("setSupportZoom") && m.getParameterCount() == 1 && m.getParameterTypes()[0] == boolean.class) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            param.args[0] = true;
                            logCall(className, methodName, "force true");
                        }
                    });
                    continue;
                }

                if (methodName.equals("isZoomAvailable") || methodName.equals("isZoomAvailableCaptureState")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                            logCall(className, methodName, "-> true");
                        }
                    });
                    continue;
                }

                if (methodName.equals("checkValidZoomLevel")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            normalizeNumericArgs(param.args);
                            logCall(className, methodName, "args normalized");
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (returnType == boolean.class || returnType == Boolean.class) {
                                param.setResult(true);
                            } else if (returnType == float.class || returnType == Float.class) {
                                param.setResult(resolveRequestedFloat(param.args));
                            } else if (returnType == double.class || returnType == Double.class) {
                                param.setResult((double) resolveRequestedFloat(param.args));
                            } else if (returnType == int.class || returnType == Integer.class) {
                                param.setResult(Math.round(resolveRequestedFloat(param.args) * 100f));
                            }
                            logCall(className, methodName, "result relaxed");
                        }
                    });
                    continue;
                }

                if (methodName.equals("showZoomSlider")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            forceBooleanArgsTrue(param.args);
                            logCall(className, methodName, "bool args forced true");
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (returnType == boolean.class || returnType == Boolean.class) {
                                param.setResult(true);
                            }
                            logCall(className, methodName, "shown");
                        }
                    });
                    continue;
                }

                if (methodName.equals("onZoomValueChangeEventRequested")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            normalizeNumericArgs(param.args);
                            logCall(className, methodName, describeArgs(param.args));
                        }
                    });
                    continue;
                }

                if (methodName.equals("getKeepPortraitZoom") || methodName.equals("isKeepPortraitZoom")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                            logCall(className, methodName, "-> true");
                        }
                    });
                    continue;
                }

                if (methodName.equals("setKeepPortraitZoom") && m.getParameterCount() == 1) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args[0] instanceof Boolean) {
                                param.args[0] = true;
                            }
                            logCall(className, methodName, "force true");
                        }
                    });
                    continue;
                }

                if ((lower.contains("zoom") || lower.contains("portrait")) &&
                        (lower.startsWith("is") || lower.startsWith("has") || lower.startsWith("can")) &&
                        (returnType == boolean.class || returnType == Boolean.class) &&
                        !lower.contains("record") && !lower.contains("animation") && !lower.contains("quicktake")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                            logCall(className, methodName, "generic -> true");
                        }
                    });
                }
            }
        } catch (Throwable t) {
            log("Skip class " + className + ": " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private void hookToastSuppression(ClassLoader cl) {
        try {
            Class<?> toast = XposedHelpers.findClass("android.widget.Toast", cl);
            XposedHelpers.findAndHookMethod(toast, "makeText", Context.class, CharSequence.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args != null && param.args.length >= 2 && param.args[1] instanceof CharSequence) {
                                String s = param.args[1].toString().toLowerCase(Locale.ROOT);
                                if (looksLikeBlockedZoomToast(s)) {
                                    param.args[1] = "Portrait zoom unlock v2 active";
                                    log("Toast text replaced");
                                }
                            }
                        }
                    });

            XposedHelpers.findAndHookMethod(toast, "makeText", Context.class, int.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                Context ctx = (Context) param.args[0];
                                int resId = (Integer) param.args[1];
                                String entryName = ctx.getResources().getResourceEntryName(resId);
                                if (entryName != null && entryName.toLowerCase(Locale.ROOT).contains("not_supported_zoom_toast_popup")) {
                                    param.args[1] = getSafeStringResId(ctx, "screen_flash_indicator_text");
                                    log("Toast resource replaced from " + entryName);
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                    });
        } catch (Throwable t) {
            log("Toast hook skipped: " + t.getMessage());
        }
    }

    private boolean looksLikeBlockedZoomToast(String s) {
        return s.contains("tidak dapat memperbesar")
                || s.contains("cannot zoom")
                || s.contains("memperbesar atau memperkecil")
                || s.contains("zoom is not supported");
    }

    private int getSafeStringResId(Context ctx, String entryName) {
        try {
            Resources r = ctx.getResources();
            int id = r.getIdentifier(entryName, "string", ctx.getPackageName());
            return id != 0 ? id : android.R.string.ok;
        } catch (Throwable t) {
            return android.R.string.ok;
        }
    }

    private void normalizeNumericArgs(Object[] args) {
        if (args == null) return;
        for (int i = 0; i < args.length; i++) {
            Object arg = args[i];
            if (arg instanceof Float) {
                args[i] = clamp((Float) arg);
            } else if (arg instanceof Double) {
                args[i] = (double) clamp(((Double) arg).floatValue());
            } else if (arg instanceof Integer) {
                int v = (Integer) arg;
                if (v < 0) v = Math.round(DEFAULT_ZOOM * 100f);
                args[i] = v;
            }
        }
    }

    private void forceBooleanArgsTrue(Object[] args) {
        if (args == null) return;
        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof Boolean) args[i] = true;
        }
    }

    private float resolveRequestedFloat(Object[] args) {
        if (args != null) {
            for (Object arg : args) {
                if (arg instanceof Float) return clamp((Float) arg);
                if (arg instanceof Double) return clamp(((Double) arg).floatValue());
                if (arg instanceof Integer) {
                    int v = (Integer) arg;
                    if (v > 10) return clamp(v / 100f);
                    if (v > 0) return clamp((float) v);
                }
            }
        }
        return DEFAULT_ZOOM;
    }

    private float clamp(float v) {
        if (Float.isNaN(v) || Float.isInfinite(v)) return DEFAULT_ZOOM;
        if (v < MIN_ZOOM) return MIN_ZOOM;
        if (v > MAX_ZOOM) return MAX_ZOOM;
        return v;
    }

    private String describeArgs(Object[] args) {
        if (args == null || args.length == 0) return "no args";
        StringBuilder sb = new StringBuilder();
        for (Object arg : args) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(arg == null ? "null" : arg.toString());
        }
        return sb.toString();
    }

    private void logCall(String cls, String method, String detail) {
        String key = cls + "#" + method + ":" + detail;
        if (loggedCalls.add(key)) {
            log(cls.substring(cls.lastIndexOf('.') + 1) + "." + method + " " + detail);
        }
    }

    private static void log(String msg) {
        XposedBridge.log("[A54PortraitZoomV2] " + msg);
    }
}
