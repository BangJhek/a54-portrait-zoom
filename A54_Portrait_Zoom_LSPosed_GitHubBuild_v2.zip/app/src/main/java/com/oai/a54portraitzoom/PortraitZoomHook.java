package com.oai.a54portraitzoom;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class PortraitZoomHook implements IXposedHookLoadPackage {
    private static final String TARGET_PKG = "com.sec.android.app.camera";
    private static final Set<String> TARGET_CLASSES = new HashSet<>(Arrays.asList(
            "com.sec.android.app.camera.shootingmode.common.zoom.ShootingModeZoomController",
            "com.sec.android.app.camera.shootingmode.ShootingModeZoomControllerFactory",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitView",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitView",
            "com.sec.android.app.camera.layer.keyscreen.zoom.slider.ZoomSliderPresenter",
            "com.sec.android.app.camera.layer.keyscreen.zoom.slider.ZoomSliderView",
            "com.sec.android.app.camera.layer.keyscreen.zoom.widget.ZoomTickSlider",
            "com.sec.android.app.camera.layer.keyscreen.zoom.widget.ZoomShortcutListView",
            "com.sec.android.app.camera.layer.keyscreen.zoom.widget.ZoomShortcutListAdapter",
            "com.sec.android.app.camera.shootingmode.common.zoomrocker.ZoomRockerSlider"
    ));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) return;
        log("Loaded Samsung Camera process=" + lpparam.processName + ", installing v4 slider hooks");

        for (String cls : TARGET_CLASSES) {
            hookTargetClass(lpparam.classLoader, cls);
        }

        installToastBlock(lpparam.classLoader);
    }

    private void hookTargetClass(ClassLoader cl, String className) {
        try {
            Class<?> cls = XposedHelpers.findClass(className, cl);
            log("Hooking class: " + className);

            for (Method m : cls.getDeclaredMethods()) {
                final String name = m.getName();
                final String lower = name.toLowerCase(Locale.ROOT);
                final Class<?> rt = m.getReturnType();
                final int pc = m.getParameterCount();

                if (Modifier.isAbstract(m.getModifiers()) || Modifier.isNative(m.getModifiers())) continue;

                // Kill hide/collapse/restriction paths so slider stays visible.
                if (name.equals("collapseZoomSlider")
                        || name.equals("handleZoomSliderCollapse")
                        || name.equals("hideZoomSlider")
                        || name.equals("hideZoomShortcut")
                        || name.equals("hideZoomRockerSlider")
                        || name.equals("onZoomSliderHide")
                        || name.equals("showZoomNotSupportedToast")
                        || name.equals("showZoomRestrictionToast")
                        || name.equals("onZoomNotSupportedToastShowRequested")
                        || name.equals("onZoomRestrictionToastShowRequested")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            log("No-op UI gate: " + className + "#" + name);
                            setNeutralResult(param, rt);
                        }
                    });
                    continue;
                }

                // Force any obvious slider/shortcut/visibility/availability gate to true.
                if ((rt == boolean.class || rt == Boolean.class) && isLikelyUiZoomGate(lower)) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                            if (lower.contains("slider") || lower.contains("shortcut") || lower.contains("available") || lower.contains("visible") || lower.contains("expanded") || lower.contains("init")) {
                                log("Forced UI gate true: " + className + "#" + name);
                            }
                        }
                    });
                    continue;
                }

                // Push zoom UI to visible/expanded after key setup points.
                if (name.equals("initializeZoomSliderView")
                        || name.equals("setShootingModeZoomController")
                        || name.equals("showZoomSlider")
                        || name.equals("showZoomLensShortcut")
                        || name.equals("showZoomShortcut")
                        || name.equals("onZoomShortcutShow")
                        || name.equals("expandZoomSlider")
                        || name.equals("notifyZoomShortCutList")
                        || name.equals("changeZoomTextSliderType")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            coerceArgs(name, param.args);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            forceUiExpand(param.thisObject);
                            if (param.args != null) {
                                for (Object a : param.args) {
                                    if (a != null) forceUiExpand(a);
                                }
                            }
                            if (name.equals("initializeZoomSliderView") || name.equals("setShootingModeZoomController")) {
                                log("Triggered UI expand after " + className + "#" + name);
                            }
                        }
                    });
                    continue;
                }

                // Keep portrait zoom state enabled.
                if ((name.equals("setKeepPortraitZoom") && pc == 1)
                        || name.equals("getKeepPortraitZoom")
                        || name.equals("isKeepPortraitZoom")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (name.equals("setKeepPortraitZoom") && param.args != null && param.args.length == 1) {
                                param.args[0] = true;
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                        }
                    });
                    continue;
                }

                // Relax validity/selection checks.
                if (name.equals("checkValidZoomLevel")
                        || name.equals("validateZoomLensDataList")
                        || name.equals("canUpdateZoom")
                        || name.equals("handleZoomShortcutButtonClickEvent")
                        || name.equals("onZoomShortcutButtonClicked")
                        || name.equals("onZoomShortcutSelection")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            coerceArgs(name, param.args);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            } else if (rt == int.class || rt == Integer.class) {
                                param.setResult(1);
                            }
                            forceUiExpand(param.thisObject);
                            log("Relaxed zoom validation path: " + className + "#" + name);
                        }
                    });
                    continue;
                }

                // Normalize zoom values so slider has sane range.
                if (name.equals("getDefaultPortraitZoom")
                        || name.equals("getBokehLensZoomValue")
                        || name.equals("getMinZoomValue")
                        || name.equals("getMaxZoomValue")
                        || name.equals("getZoomValue")
                        || name.equals("getDisplayZoomValue")
                        || name.equals("getWideZoomShortcutLevel")
                        || name.equals("getTeleZoomShortcutLevel")
                        || name.equals("getSecondTeleZoomShortcutLevel")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            fixNumericResult(name, rt, param);
                        }
                    });
                    continue;
                }

                if (name.equals("setZoomValue")
                        || name.equals("setZoomLevel")
                        || name.equals("updateZoomValue")
                        || name.equals("notifyZoomLevel")
                        || name.equals("onZoomValueChangeEventRequested")
                        || name.equals("onZoomValueChangeRequested")
                        || name.equals("scrollSliderByZoomValue")
                        || name.equals("changeZoomTextSliderType")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            coerceArgs(name, param.args);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                            forceUiExpand(param.thisObject);
                        }
                    });
                    continue;
                }

                // If the shortcut command list comes back null, at least keep it non-null.
                if (name.equals("getZoomShortcutCommandIdList") && List.class.isAssignableFrom(rt)) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.getResult() == null) {
                                param.setResult(new java.util.ArrayList<>());
                                log("Normalized null shortcut list: " + className + "#" + name);
                            }
                        }
                    });
                }
            }
        } catch (Throwable t) {
            log("Skip class " + className + ": " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private boolean isLikelyUiZoomGate(String lower) {
        boolean mentionsZoom = lower.contains("zoom") || lower.contains("slider") || lower.contains("shortcut") || lower.contains("portrait") || lower.contains("bokeh");
        boolean isGate = lower.startsWith("is") || lower.startsWith("can") || lower.startsWith("has")
                || lower.contains("support") || lower.contains("available") || lower.contains("visible")
                || lower.contains("expanded") || lower.contains("show") || lower.contains("enable")
                || lower.contains("init") || lower.contains("display");
        boolean negative = lower.contains("notsupported") || lower.contains("restriction") || lower.contains("hide") || lower.contains("collapse");
        return mentionsZoom && isGate && !negative;
    }

    private void coerceArgs(String name, Object[] args) {
        if (args == null) return;
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (a instanceof Boolean) {
                args[i] = true;
            } else if (a instanceof Float) {
                float v = (Float) a;
                if (name.toLowerCase(Locale.ROOT).contains("min")) v = 0.5f;
                else if (name.toLowerCase(Locale.ROOT).contains("max")) v = Math.max(v, 2.0f);
                else if (v < 0.5f) v = 1.0f;
                else if (v > 10.0f) v = 2.0f;
                args[i] = v;
            } else if (a instanceof Double) {
                double v = (Double) a;
                if (name.toLowerCase(Locale.ROOT).contains("min")) v = 0.5d;
                else if (name.toLowerCase(Locale.ROOT).contains("max")) v = Math.max(v, 2.0d);
                else if (v < 0.5d) v = 1.0d;
                else if (v > 10.0d) v = 2.0d;
                args[i] = v;
            } else if (a instanceof Integer) {
                int v = (Integer) a;
                if (v < 0) v = 1;
                args[i] = v;
            }
        }
    }

    private void fixNumericResult(String name, Class<?> rt, XC_MethodHook.MethodHookParam param) {
        if (rt == float.class || rt == Float.class) {
            float v = param.getResult() instanceof Number ? ((Number) param.getResult()).floatValue() : 1.0f;
            if (name.contains("Min")) v = 0.5f;
            else if (name.contains("Max")) v = Math.max(v, 2.0f);
            else if (name.contains("Wide")) v = 0.5f;
            else if (name.contains("Tele")) v = 2.0f;
            else if (v < 0.5f) v = 1.0f;
            param.setResult(v);
        } else if (rt == double.class || rt == Double.class) {
            double v = param.getResult() instanceof Number ? ((Number) param.getResult()).doubleValue() : 1.0d;
            if (name.contains("Min")) v = 0.5d;
            else if (name.contains("Max")) v = Math.max(v, 2.0d);
            else if (name.contains("Wide")) v = 0.5d;
            else if (name.contains("Tele")) v = 2.0d;
            else if (v < 0.5d) v = 1.0d;
            param.setResult(v);
        } else if (rt == int.class || rt == Integer.class) {
            int v = param.getResult() instanceof Number ? ((Number) param.getResult()).intValue() : 1;
            if (name.contains("Min")) v = 0;
            else if (name.contains("Max")) v = Math.max(v, 2);
            else if (name.contains("Wide")) v = 0;
            else if (name.contains("Tele")) v = 2;
            else if (v < 0) v = 1;
            param.setResult(v);
        }
    }

    private void forceUiExpand(Object obj) {
        if (obj == null) return;
        callZeroArgIfExists(obj, "initializeZoomSliderView");
        callZeroArgIfExists(obj, "expandZoomSlider");
        callZeroArgIfExists(obj, "showZoomSlider");
        callZeroArgIfExists(obj, "showZoomLensShortcut");
        callZeroArgIfExists(obj, "showZoomShortcut");
        callZeroArgIfExists(obj, "onZoomShortcutShow");
        callZeroArgIfExists(obj, "notifyZoomShortCutList");
    }

    private void callZeroArgIfExists(Object obj, String methodName) {
        try {
            Method[] methods = obj.getClass().getDeclaredMethods();
            for (Method m : methods) {
                if (!m.getName().equals(methodName) || m.getParameterCount() != 0) continue;
                m.setAccessible(true);
                m.invoke(obj);
                log("Invoked " + obj.getClass().getSimpleName() + "#" + methodName + "()");
                return;
            }
        } catch (Throwable t) {
            log("Invoke skip " + obj.getClass().getSimpleName() + "#" + methodName + ": " + t.getClass().getSimpleName());
        }
    }

    private void installToastBlock(ClassLoader cl) {
        try {
            Class<?> toast = XposedHelpers.findClass("android.widget.Toast", cl);
            XposedHelpers.findAndHookMethod(toast, "makeText", android.content.Context.class, CharSequence.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args != null && param.args.length >= 2 && param.args[1] instanceof CharSequence) {
                                String s = param.args[1].toString().toLowerCase(Locale.ROOT);
                                if (s.contains("tidak dapat memperbesar")
                                        || s.contains("cannot zoom")
                                        || s.contains("memperbesar atau memperkecil")
                                        || s.contains("zoom not supported")) {
                                    log("Blocked zoom toast text");
                                    param.args[1] = "Portrait zoom slider unlock v4 active";
                                }
                            }
                        }
                    });
        } catch (Throwable t) {
            log("Toast hook skipped: " + t.getMessage());
        }
    }

    private void setNeutralResult(XC_MethodHook.MethodHookParam param, Class<?> rt) {
        if (rt == boolean.class || rt == Boolean.class) param.setResult(true);
        else if (rt == int.class || rt == Integer.class) param.setResult(0);
        else if (rt == float.class || rt == Float.class) param.setResult(1.0f);
        else if (rt == double.class || rt == Double.class) param.setResult(1.0d);
        else param.setResult(null);
    }

    private static void log(String msg) {
        XposedBridge.log("[A54PortraitZoomV4] " + msg);
    }
}
