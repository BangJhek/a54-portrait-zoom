package com.oai.a54portraitzoom;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class PortraitZoomHook implements IXposedHookLoadPackage {
    private static final String TARGET_PKG = "com.sec.android.app.camera";
    private static final Set<String> TARGET_CLASSES = new HashSet<>(Arrays.asList(
            "com.sec.android.app.camera.shootingmode.portrait.PortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitView",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitView"
    ));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) return;

        log("Loaded Samsung Camera, installing portrait zoom hooks");

        for (String cls : TARGET_CLASSES) {
            hookTargetClass(lpparam.classLoader, cls);
        }

        hideZoomBlockedToasts(lpparam.classLoader);
    }

    private void hookTargetClass(ClassLoader cl, String className) {
        try {
            Class<?> cls = XposedHelpers.findClass(className, cl);
            log("Hooking class: " + className);

            for (Method m : cls.getDeclaredMethods()) {
                String n = m.getName();
                Class<?> rt = m.getReturnType();
                String lower = n.toLowerCase(Locale.ROOT);

                // Force setters that disable zoom.
                if (n.equals("setSupportZoom") && m.getParameterCount() == 1 && m.getParameterTypes()[0] == boolean.class) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            param.args[0] = true;
                        }
                    });
                    continue;
                }

                // Force boolean gates to true for portrait zoom-related checks.
                if (rt == boolean.class && isLikelyZoomGate(lower)) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                        }
                    });
                    continue;
                }

                // Keep portrait zoom preference on.
                if ((n.equals("getKeepPortraitZoom") || n.equals("setKeepPortraitZoom")) ) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if ("setKeepPortraitZoom".equals(n) && param.args != null && param.args.length == 1 && param.args[0] instanceof Boolean) {
                                param.args[0] = true;
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (m.getReturnType() == boolean.class || m.getReturnType() == Boolean.class) {
                                param.setResult(true);
                            }
                        }
                    });
                    continue;
                }

                // Nudge default zoom methods toward sane values if they are primitive numeric.
                if (n.equals("getDefaultPortraitZoom") || n.equals("getBokehLensZoomValue")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            Class<?> r = m.getReturnType();
                            if (r == float.class || r == Float.class) {
                                Object cur = param.getResult();
                                float v = (cur instanceof Number) ? ((Number) cur).floatValue() : 1.0f;
                                if (v < 0.5f) v = 1.0f;
                                param.setResult(v);
                            } else if (r == double.class || r == Double.class) {
                                Object cur = param.getResult();
                                double v = (cur instanceof Number) ? ((Number) cur).doubleValue() : 1.0d;
                                if (v < 0.5d) v = 1.0d;
                                param.setResult(v);
                            } else if (r == int.class || r == Integer.class) {
                                Object cur = param.getResult();
                                int v = (cur instanceof Number) ? ((Number) cur).intValue() : 1;
                                if (v < 0) v = 1;
                                param.setResult(v);
                            }
                        }
                    });
                    continue;
                }
            }
        } catch (Throwable t) {
            log("Skip class " + className + ": " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private boolean isLikelyZoomGate(String lower) {
        boolean mentionsZoom = lower.contains("zoom") || lower.contains("portrait");
        boolean isGate = lower.startsWith("is") || lower.startsWith("has") || lower.startsWith("can")
                || lower.contains("support") || lower.contains("available")
                || lower.contains("enable") || lower.contains("show");
        boolean clearlyNegative = lower.contains("invalid") || lower.contains("blocked") || lower.contains("disabled");
        return mentionsZoom && isGate && !clearlyNegative;
    }

    private void hideZoomBlockedToasts(ClassLoader cl) {
        try {
            Class<?> toast = XposedHelpers.findClass("android.widget.Toast", cl);
            XposedHelpers.findAndHookMethod(toast, "makeText", android.content.Context.class, CharSequence.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args != null && param.args.length >= 2 && param.args[1] instanceof CharSequence) {
                                String s = param.args[1].toString().toLowerCase(Locale.ROOT);
                                if (s.contains("tidak dapat memperbesar") || s.contains("cannot zoom") || s.contains("memperbesar atau memperkecil")) {
                                    param.args[1] = "Portrait zoom unlock active";
                                }
                            }
                        }
                    });
        } catch (Throwable t) {
            log("Toast hook skipped: " + t.getMessage());
        }
    }

    private static void log(String msg) {
        XposedBridge.log("[A54PortraitZoom] " + msg);
    }
}
