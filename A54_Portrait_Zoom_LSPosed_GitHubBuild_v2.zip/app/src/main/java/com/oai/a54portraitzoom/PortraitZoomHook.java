package com.oai.a54portraitzoom;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class PortraitZoomHook implements IXposedHookLoadPackage {
    private static final String TARGET_PKG = "com.sec.android.app.camera";
    private static final Set<String> TARGET_CLASSES = new HashSet<>(Arrays.asList(
            "com.sec.android.app.camera.shootingmode.common.zoom.ShootingModeZoomController",
            "com.sec.android.app.camera.shootingmode.ShootingModeZoomControllerFactory",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitZoomController",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitPresenter",
            "com.sec.android.app.camera.shootingmode.portrait.PortraitView",
            "com.sec.android.app.camera.shootingmode.portrait.SingleBokehPortraitView"
    ));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) return;

        log("Loaded Samsung Camera process=" + lpparam.processName + ", installing v3 hooks");

        for (String cls : TARGET_CLASSES) {
            hookTargetClass(lpparam.classLoader, cls);
        }

        installToastBlock(lpparam.classLoader);
    }

    private void hookTargetClass(ClassLoader cl, String className) {
        try {
            Class<?> cls = XposedHelpers.findClass(className, cl);
            log("Hooking class: " + className);

            for (Method m : cls.getDeclaredMethods()) {
                final String name = m.getName();
                final String lower = name.toLowerCase(Locale.ROOT);
                final Class<?> rt = m.getReturnType();
                final int pc = m.getParameterCount();

                // Hard bypass for common "zoom not supported" flows.
                if (name.equals("showZoomNotSupportedToast")
                        || name.equals("onZoomNotSupportedToastShowRequested")
                        || name.equals("showZoomRestrictionToast")
                        || name.equals("onZoomRestrictionToastShowRequested")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            log("Suppressed toast gate via " + className + "#" + name);
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            } else {
                                param.setResult(null);
                            }
                        }
                    });
                    continue;
                }

                // Force general zoom-support gates to true.
                if ((rt == boolean.class || rt == Boolean.class)
                        && (lower.contains("zoom") || lower.contains("bokeh") || lower.contains("portrait"))
                        && (lower.startsWith("is") || lower.startsWith("can") || lower.startsWith("has")
                        || lower.contains("support") || lower.contains("available") || lower.contains("valid")
                        || lower.contains("show") || lower.contains("enable"))) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                            if (lower.contains("valid") || lower.contains("available") || lower.contains("support")) {
                                log("Forced boolean gate true: " + className + "#" + name);
                            }
                        }
                    });
                    continue;
                }

                // Some setters explicitly disable zoom.
                if (name.equals("setSupportZoom") && pc == 1 && m.getParameterTypes()[0] == boolean.class) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            param.args[0] = true;
                            log("Forced setSupportZoom(true)");
                        }
                    });
                    continue;
                }

                // Keep portrait zoom state on.
                if ((name.equals("setKeepPortraitZoom") && pc == 1)
                        || name.equals("getKeepPortraitZoom")
                        || name.equals("isKeepPortraitZoom")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (name.equals("setKeepPortraitZoom") && param.args != null && param.args.length == 1) {
                                param.args[0] = true;
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                        }
                    });
                    continue;
                }

                // Relax validity checks.
                if (name.equals("checkValidZoomLevel") || name.equals("validateZoomLensDataList") || name.equals("canUpdateZoom")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            } else if (rt == int.class || rt == Integer.class) {
                                param.setResult(1);
                            }
                            log("Relaxed zoom validity gate: " + className + "#" + name);
                        }
                    });
                    continue;
                }

                // Force UI exposure for zoom controls.
                if (name.equals("showZoomSlider")
                        || name.equals("showZoomShortcut")
                        || name.equals("showZoomLensShortcut")
                        || name.equals("showZoomText")
                        || name.equals("showZoomRockerSlider")
                        || name.equals("showZoomRockerText")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args != null) {
                                for (int i = 0; i < param.args.length; i++) {
                                    if (param.args[i] instanceof Boolean) param.args[i] = true;
                                    if (param.args[i] instanceof Integer && ((Integer) param.args[i]) < 0) param.args[i] = 0;
                                }
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                        }
                    });
                    continue;
                }

                // Normalize zoom change requests.
                if (name.equals("onZoomValueChangeEventRequested")
                        || name.equals("onZoomValueChangeRequested")
                        || name.equals("updateZoomValue")
                        || name.equals("setZoomValue")
                        || name.equals("setZoomLevel")
                        || name.equals("notifyZoomLevel")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args != null) {
                                for (int i = 0; i < param.args.length; i++) {
                                    Object a = param.args[i];
                                    if (a instanceof Float) {
                                        float v = (Float) a;
                                        if (v < 0.5f) v = 1.0f;
                                        if (v > 10.0f) v = 2.0f;
                                        param.args[i] = v;
                                    } else if (a instanceof Double) {
                                        double v = (Double) a;
                                        if (v < 0.5d) v = 1.0d;
                                        if (v > 10.0d) v = 2.0d;
                                        param.args[i] = v;
                                    } else if (a instanceof Integer) {
                                        int v = (Integer) a;
                                        if (v < 0) v = 1;
                                        param.args[i] = v;
                                    } else if (a instanceof Boolean) {
                                        param.args[i] = true;
                                    }
                                }
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == boolean.class || rt == Boolean.class) {
                                param.setResult(true);
                            }
                        }
                    });
                    continue;
                }

                // Give sane defaults for min/max/default zoom.
                if (name.equals("getDefaultPortraitZoom")
                        || name.equals("getBokehLensZoomValue")
                        || name.equals("getMinZoomValue")
                        || name.equals("getMaxZoomValue")
                        || name.equals("getZoomValue")
                        || name.equals("getDisplayZoomValue")) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (rt == float.class || rt == Float.class) {
                                float v = param.getResult() instanceof Number ? ((Number) param.getResult()).floatValue() : 1.0f;
                                if (name.contains("Min")) v = Math.min(v, 0.5f);
                                else if (name.contains("Max")) v = Math.max(v, 2.0f);
                                else if (v < 0.5f) v = 1.0f;
                                param.setResult(v);
                            } else if (rt == double.class || rt == Double.class) {
                                double v = param.getResult() instanceof Number ? ((Number) param.getResult()).doubleValue() : 1.0d;
                                if (name.contains("Min")) v = Math.min(v, 0.5d);
                                else if (name.contains("Max")) v = Math.max(v, 2.0d);
                                else if (v < 0.5d) v = 1.0d;
                                param.setResult(v);
                            } else if (rt == int.class || rt == Integer.class) {
                                int v = param.getResult() instanceof Number ? ((Number) param.getResult()).intValue() : 1;
                                if (name.contains("Min")) v = Math.min(v, 0);
                                else if (name.contains("Max")) v = Math.max(v, 2);
                                else if (v < 0) v = 1;
                                param.setResult(v);
                            }
                        }
                    });
                }
            }
        } catch (Throwable t) {
            log("Skip class " + className + ": " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private void installToastBlock(ClassLoader cl) {
        try {
            Class<?> toast = XposedHelpers.findClass("android.widget.Toast", cl);
            XposedHelpers.findAndHookMethod(toast, "makeText", android.content.Context.class, CharSequence.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args != null && param.args.length >= 2 && param.args[1] instanceof CharSequence) {
                                String s = param.args[1].toString().toLowerCase(Locale.ROOT);
                                if (s.contains("tidak dapat memperbesar")
                                        || s.contains("cannot zoom")
                                        || s.contains("memperbesar atau memperkecil")
                                        || s.contains("zoom not supported")) {
                                    log("Blocked zoom toast text");
                                    param.args[1] = "Portrait zoom unlock v3 active";
                                }
                            }
                        }
                    });
        } catch (Throwable t) {
            log("Toast hook skipped: " + t.getMessage());
        }
    }

    private static void log(String msg) {
        XposedBridge.log("[A54PortraitZoomV3] " + msg);
    }
}
